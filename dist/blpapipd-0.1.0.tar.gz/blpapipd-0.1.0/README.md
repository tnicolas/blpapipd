# blpapipd

Extract Bloomberg (BBG) data into pandas timeseries object w/ caching.  Leverages blpapi desktop api in Python
Use accompanying plot_utilities to plot results
See examples/barc_hy_vs_ig.ipynb for a use case of the package

To install prerequisite blpapi package, use command below:
python -m pip install --index-url=https://bcms.bloomberg.com/pip/simple blpapi

Send inquiries to t@steinbachs.us

